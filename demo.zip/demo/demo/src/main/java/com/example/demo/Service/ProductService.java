package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Product;
import com.example.demo.Repository.ProductRepository;
@Service
public class ProductService {
  
  @Autowired
  private ProductRepository productRepository;
  
  public List<Product> getAllProducts() {
    return productRepository.findAll();
  }
  
  public Product getProductById(Long id) {
    return productRepository.findById(id).orElse(null);
  }
  
  public Product createProduct(Product product) {
    return productRepository.save(product);
  }
  
  public Product updateProduct(Product product) {
    Product existingProduct = getProductById(product.getId());
    if (existingProduct != null) {
      existingProduct.setName(product.getName());
      existingProduct.setDescription(product.getDescription());
      existingProduct.setPrice(product.getPrice());
      return productRepository.save(existingProduct);
    } else {
      return null;
    }
  }
  
  public void deleteProduct(Long id) {
    productRepository.deleteById(id);
  }
}