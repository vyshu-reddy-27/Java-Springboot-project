document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');

    if (productId) {
        fetch(`/products/${productId}`)
            .then(response => response.json())
            .then(product => {
                document.getElementById('formTitle').textContent = 'Edit Product';
                document.getElementById('productId').value = product.id;
                document.getElementById('name').value = product.name;
                document.getElementById('description').value = product.description;
                document.getElementById('price').value = product.price;
            });
    }

    document.getElementById('productForm').addEventListener('submit', function(event) {
        event.preventDefault();

        const product = {
            id: document.getElementById('productId').value,
            name: document.getElementById('name').value,
            description: document.getElementById('description').value,
            price: document.getElementById('price').value
        };

        const method = product.id ? 'PUT' : 'POST';
        const url = product.id ? `/products/${product.id}` : '/products';

        fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(product)
        }).then(() => {
            window.location.href = '/product-list.html';
        });
    });
});
