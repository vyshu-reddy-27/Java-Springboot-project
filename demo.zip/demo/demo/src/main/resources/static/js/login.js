document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const user = {
        username: document.getElementById('username').value,
        password: document.getElementById('password').value
    };

    fetch('/users/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(user)
    }).then(response => {
        if (response.ok) {
            window.location.href = '/product-list.html';
        } else {
            alert('Login failed');
        }
    });
});
